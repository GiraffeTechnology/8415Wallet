8415wallet approved UI Beta candidate

This private candidate contains the implemented wallet UI and three distinct DApp
profiles. It is not an approved release and must not replace the earlier approved
handoff. Draft PR 56 remains unmerged because exact-head hosted CI failed before
any job step started, and rendered Chromium acceptance could not run.

Source
  PR: https://github.com/GiraffeTechnology/8415Wallet/pull/56
  Commit: bc203c7225e5e8898cdff3303981c9ef63b8f931
  Git content tree: 904fb9805903afc12a83b3dde1756fa79dbcc394
  Base: localization PR 55, on authentication PR 54
  Every DApp manifest records this exact clean source commit and tree.

Packages
  v2-platform: 8415wallet V2 platform, standalone foundation
  v2-xiongan: Xiongan V2 tenant, no V3 responsibility controls
  v3-platform: 8415wallet V3 platform, foundation plus linked responsibilities
  sdk: supporting V2 and V3 integration packages, not substitute DApps
  source: exact source export; no production configuration or credentials added

Verification
  Node 24.19.0 typecheck and browser build passed.
  Node tests: 1,266 passed. Local EVM: 89 passed.
  DApp packaging regression: 16 passed.
  V2 SDK installation: 8/8. V3 SDK installation: 9/9.
  All three DApp archives passed inventory/import/config/PRD/source verification.
  Repeated builds of each profile produced byte-identical archives.
  Independent source review found no unresolved P0/P1/P2 issue after fixes.
  This is not an independent security audit.

Required gates
  Hosted CI run 37234235755 failed before startup for both Node 22 and 24:
  no runner and zero executed steps. Local Chromium fails at socket creation;
  the cloud browser also blocks the loopback preview. No rendered, pixel-perfect,
  physical-device, real-wallet or public-testnet acceptance is claimed.
  Merge only after all required checks run and pass on the exact PR head.

Use and reproduce
  1. Check this bundle using SHA256SUMS. Each DApp also contains its own manifest
     and full file inventory. Keep web/ and dist/browser/ together when extracted.
  2. Check out the exact commit above in the authorized private repository.
     Use Node 24.19.0 and npm ci. Run npm run typecheck, npm test,
     npm run test:evm and npm run wallet:browser:build.
  3. Rebuild platform profiles with npm run pack:dapp:all.
     Rebuild Xiongan with:
     npm run pack:dapp:v2 -- --config config/releases/xiongan-v2.json
     Run npm run pack:dapp:verify for the profiles currently in dist/.
  4. On a working Chromium executor, run all CI browser suites, including
     scripts/controls/approved-ui-smoke.cjs. They use synthetic local providers,
     not genuine wallets. Review the generated desktop/mobile evidence.
  5. Read ACCOUNT-AUTHENTICATION.md before configuring a same-origin account
     service. Password/TOTP and hardware CA require independently configured
     server bindings or a compatible device bridge. Never put real secrets into
     this bundle or source control.

All packaged deployment URLs are null and environment is unconfigured. No host
or web port is assigned by this candidate. Hosting requires the existing confirmed
allocation; TCP 443 remains reserved for SSH. Preserve the origin and existing
operation journals during any authorized deployment or rollback. Do not deploy,
send real transactions or change production configuration merely to test this ZIP.

Product details
  NFTs and native ERC-8415 are first; ETH/ERC-20 remain available. Owner, holder,
  finality, contest/gap and freshness stay separate. Full reviewed addresses and
  raw amounts are retained. Token metadata is never translated. The giraffe JPEG
  is byte-identical to the original. Tenant avatars persist only in this browser
  for the specific origin/profile/tenant and do not alter server configuration.
