DApp branch synchronization recovery

source/ is the complete candidate 67-file deployment-branch tree (including only CI/operator metadata outside the 62-file public payload). The .git directory and synthetic local base commit are intentionally omitted. Apply sync.patch to a normal checkout of the real deployment base 8c786de7eee7a54bb086fb36102066c3994d7805; do not push a reconstructed history.

This checkpoint preserves candidate source, full hashes, local tests and CI plan before publication. The deployable public bytes are exactly the previously delivered and tested 763b0067 static artifact, not a new independently built product. No server deployment or real wallet operation has occurred.
Final result: PR46 merged to deploy/xiongan-sin, release commit 1ccafcdd769e9c41e3531876ace1b9714fdc932b, tree 18df32c7a222af677dc224a2d375b7797d48d636. Both the exact PR head CI and release-branch push CI passed their complete Node22/24 matrix. Each job checked 62 hashes and passed 11 artifact tests. All 67 merged Git blobs match the saved candidate; DOMAIN and the other 59 public assets remain unchanged. The original delivery ZIP Library version 2 is unchanged. Fixed operator entry: https://github.com/GiraffeTechnology/8415Wallet/blob/1ccafcdd769e9c41e3531876ace1b9714fdc932b/DEPLOY.md
No server deployment, network/SSH changes, credentials or genuine-wallet transaction.
