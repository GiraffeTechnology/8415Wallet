import { ExternalAssetSession } from './sdk/package/xiongan/externalAssets.js';
const actor='0x1111111111111111111111111111111111111111';
const recipient='0x2222222222222222222222222222222222222222';
const blockHash='0x'+'a'.repeat(64), now=BigInt(Math.floor(Date.now()/1000));
let stored=null;const calls=[];
const clone=x=>x===null?null:JSON.parse(JSON.stringify(x));
const store={async read(){return clone(stored)},async compareAndSwap(expected,next){if((stored?.revision??null)!==expected)return false;stored=clone(next);return true;}};
const provider={async request({method,params}){
 calls.push({method,params});
 switch(method){
 case 'eth_chainId':return '0xaa36a7';
 case 'eth_accounts':case 'eth_requestAccounts':return [actor];
 case 'eth_getCode':return '0x';
 case 'eth_getBalance':return '0xde0b6b3a7640000';
 case 'eth_getTransactionCount':return '0x0';
 case 'eth_estimateGas':return '0x5208';
 case 'eth_getBlockByNumber':return {number:'0x100',hash:blockHash,timestamp:'0x'+now.toString(16)};
 case 'eth_getTransactionReceipt':return null;
 case 'eth_sendTransaction':throw Object.assign(new Error('Synthetic owner rejection'),{code:4001});
 default:throw new Error('Unimplemented synthetic RPC '+method);
 }
}};
const result={scope:'Synthetic Node provider + in-memory persistence. No real wallet, signing or network; not package test suite, independent security audit or chain acceptance.',node:process.version};
const session=new ExternalAssetSession(provider,'11155111',actor,store);
result.balance=await session.balance();
result.initial=await session.status();
const req={schema:'xiongan-asset-request/1',requestId:'probe-1',agent:'Owner form',chainId:'11155111',actor,expiresAt:(now+600n).toString(),action:{kind:'native-transfer',recipient,valueWei:'1000000000000000'}};
const review=await session.prepare(JSON.stringify(req));result.prepared=review;
result.sendCountBeforeReview=calls.filter(c=>c.method==='eth_sendTransaction').length;
async function attempt(name,fn){try{result[name]={ok:true,value:await fn()}}catch(e){result[name]={ok:false,name:e.name,code:e.code,message:e.message}}}
await attempt('submitRejected4001',()=>session.submit(review,review.digest));
result.afterRejection=await session.status();
await attempt('reconcileAfterRejection',()=>session.reconcile());
await attempt('ackAfterRejection',()=>session.acknowledge());
const nextReview=await session.prepare(JSON.stringify({...req,requestId:'probe-2'}));
await attempt('secondSubmit',()=>session.submit(nextReview,nextReview.digest));
result.sendCountAfterRetry=calls.filter(c=>c.method==='eth_sendTransaction').length;
const reloaded=new ExternalAssetSession(provider,'11155111',actor,store);result.reloadedState=await reloaded.status();
await attempt('unknownRequestField',()=>session.prepare(JSON.stringify({...req,arbitraryCalldata:'0x1234'})));
await attempt('wrongChain',()=>session.prepare(JSON.stringify({...req,chainId:'8453'})));
await attempt('expiredRequest',()=>session.prepare(JSON.stringify({...req,expiresAt:(now-1n).toString()})));
console.log(JSON.stringify(result,null,2));
