# Xiongan Wallet SIN deployment handoff

Rebuilt and verified 2026-10-03 UTC after the merged checksum repair, for the existing SIN deployment operator.

Deploy the fixed Xiongan Wallet browser candidate through the existing SIN hosting and operations setup. Keep the wallet's release files and route configuration separate from ArtFi and artcch. Reuse the existing approved infrastructure; this handoff does not introduce a backend, signer, RPC proxy, new hosting service, or credential store.

The user confirmed SIN as the wallet UI deployment location. The SIN deployment operator owns publication; the release owner verifies the returned evidence. This review verified GitHub and the existing static handoff, and did not deploy or change hosting configuration. The SIN executor, current host configuration, final HTTPS origin and original browser journal location still require verification by the operator. Production acceptance remains open.

## Fixed source and evidence

- Repository: GiraffeTechnology/8415Wallet, repository ID `1370406353`.
- Merged checksum repair: https://github.com/GiraffeTechnology/8415Wallet/pull/44
- Repair base: `93934f9bc5524b3989e2f10f0dc35d86b5b2835b` (previous PR #43 merge).
- Exact tested repair head: `744befce0643db1924c1cfb6531709223ee52e53`.
- Verified merged main and preferred clean-checkout commit: `763b00670752db7ed97525fca356729bbe8221d5`.
- Merge time: `2026-10-03T04:59:06Z`.
- Identical Git tree at tested repair head and merged main: `14abc51f3d882b4c882b162753fc279efcf01707`.
- Repair-head CI: https://github.com/GiraffeTechnology/8415Wallet/actions/runs/37098073411
- Post-merge main CI: https://github.com/GiraffeTechnology/8415Wallet/actions/runs/37098334390

Both exact-head and post-merge Node 22/24 CI pipelines completed successfully. Each pipeline runs typecheck, **812 Node tests with zero failures**, browser emit, **59 local EVM tests**, the reference client, and **V2 8/8** plus **V3 9/9** isolated package-install checks. Real Chromium completed desktop and narrow-viewport journeys using a synthetic provider. The test suite now checks manual form and agent JSON inputs with altered checksum characters/casing, clears an earlier review on refusal, and verifies zero sends. `CI-EVIDENCE.json` records the exact merged commit and completed job/step identities. The local container cannot launch Chromium because of a socket restriction; the hosted-runner browser results above are the actual browser evidence.

The repaired defect was mixed-case ERC-55 input checksum loss during lowercase normalization. The new candidate validates the checksum first for ETH/NFT recipients, NFT contracts, request identities and agent withdrawal destinations. Deliberately unchecksummed all-lowercase/all-uppercase addresses remain compatible, and RPC/receipt address comparison stays byte-oriented. A valid checksum does not prove recipient identity or transaction safety. Bounded independent AI-assisted source review passed 69 focused and 38 adversarial/UI checks; it is not an external professional security audit.

This newly rebuilt static archive supersedes the previous `a45971f3` handoff payload. It contains **62 public files**, including new `dist/browser/xiongan/address.js`. All 62 archived hashes/sizes and **151 relative module references** were verified. Compared with the previous 61-file payload, only `agentRequest.js`, `externalAssets.js` and the new `address.js` changed; the other 59 files are byte-identical. The seven `web/` source blobs and all 294 restored text-source blobs match the merged Git tree. No hosting, source deployment, signing or real-asset transfer was performed while preparing this handoff. Do not use the superseded payload for new transfer review.

Do not switch to an unverified newer branch tip. The historical 126 Sepolia receipts and genuine MetaMask connection/read-only results belong to the earlier `cbc3ad7217fd5066b6b97a2c2f017683a38532f2` candidate, as recorded at https://github.com/GiraffeTechnology/8415Wallet/issues/37#issuecomment-5935408065 . They do not validate the new external-account write/recovery layer. Automated tests, synthetic-provider journeys and AI-assisted source review do not establish independent external security review, genuine wallet writes, physical-device acceptance or production acceptance.

## Remaining acceptance and shortest closeout order

These are the candidate's existing open acceptance items, not additional product scope. The reproduced checksum defect was repaired in PR #44 and verified on its exact head. Any further reproduced defect from the checks below should return through a focused repair PR and exact-head regression.

1. **Verify SIN delivery.** The operator confirms the existing authorized executor, dedicated wallet origin or assessed shared-origin boundary, immutable release path and rollback reference. After publication, return the final HTTPS URL, served tree/archive identity, all 62 served file hashes, expected MIME types and headers, negative static-route checks, a real-browser load result, and unchanged ArtFi/artcch health. Those deployment facts were not observed in this review.
2. **Reconnect the original journal before any repeated intent.** Locate the original browser profile and origin, inspect its same-chain/account/controller journal and genuine-wallet activity, and preserve unresolved records. The earlier unknown outcome is still unverified. A new origin or empty profile does not close it. Do not resend an uncertain operation.
3. **Complete genuine-provider testnet flows on the served candidate.** With owner-owned signing in the genuine wallet, record Sepolia and Base Sepolia ETH-to-EOA, explicit-contract ERC-721/ERC-1155, account/chain changes, reload/disconnect, repeated-click and cross-panel prevention, rejection/unknown outcome, matching-hash recovery, speed-up and different same-nonce replacement. Bind each result to the served version, chain/account, public request digest, canonical receipt and journal transition. Keep actual chain events separate from simulated reorg tests. Current CI proves synthetic-provider behavior only.
4. **Complete required physical-device and independent-review evidence.** Record the intended physical mobile/hardware-wallet journeys and genuine provider/storage compatibility. An independent external reviewer must identify the exact version/tree and review scope, return findings and any fix/retest identities, or explicit no-findings scope. These existing acceptance gates remain open; PR merge, a green CI badge and a review-bot response do not close them.
5. **Return one acceptance record.** The SIN operator returns the evidence above to the release owner, identifying passed, failed and not-run cases and any remaining unknown outcome. The release owner decides acceptance. Mainnet/Base real-asset use remains a separate explicit acceptance decision; no new contract deployment, custodial signer or standing agent permission is part of this handoff.

## First inspect the existing SIN setup

Use the existing authorized deployment task and its Linux executor. Read its applicable repository and operations instructions before changing configuration. Record only non-secret facts:

1. The actual deployment task, host, release directory, serving software, process manager, and current configuration owner.
2. The existing HTTPS virtual host and certificate reference, including the approved wallet URL or available route. Do not invent a hostname, DNS record, listen port, or filesystem path.
3. Whether that origin already hosts a wallet journal. Identify the original browser profile, scheme, host, port, chain, account, and controller where relevant.
4. ArtFi and artcch's existing routes, release directories, workers, service workers, and health checks so the wallet change cannot overwrite or restart them.
5. Existing cache/CDN behavior, content injection, authentication, and reverse-proxy rules applicable to the wallet route. Read only the relevant configuration; do not print or copy environment files, credentials, private certificate keys, or unrelated application data.

Reuse an already approved dedicated wallet origin if one exists. A separate path on the same origin is not a browser security or IndexedDB isolation boundary: same-origin application scripts share that boundary. If only a shared origin is available, assess its existing script and service-worker scope before choosing the path; do not imply that a path prefix isolates wallet data. Resolve an unsuitable origin through the existing operator rather than silently changing hosting or access settings.

## Public static package

Recommended serving shape: serve the browser's public files directly from the existing SIN static web server. Runtime Node, npm, application secrets, and an application server are unnecessary for this shape.

The local package in this handoff directory contains exactly 62 regular files:

- `web/index.html`
- `web/app.mjs`
- `web/public-store.mjs`
- `web/wallet.css`
- `web/external-assets.mjs`
- `web/external-store.mjs`
- `web/ui-lock.mjs`
- 55 compiled JavaScript files under `dist/browser/`

Archive: `xiongan-wallet-static-763b0067.tar.gz`

Archive SHA-256: `bb66593b3f1e81ec4a319b724014bd6362d2e202a640287bedc842228b3a3187`

Archive size: 88,385 bytes. The build used Node 24.19.0 and TypeScript 5.9.3. `manifest.json` records every file hash and size. `SHA256SUMS` verifies the extracted public tree. The source tree identity, all 151 parsed relative module references, archive member list, regular-file types, and archived bytes were checked locally. The archive is a deployment candidate, not evidence that SIN serves it. `ARTIFACT-TESTS.json` records 26 checks of the freshly re-extracted checksum and request modules with a deterministic provider, zero sends and no network requests. `VERIFICATION.json` records file/reference and tree checks.

Keep `manifest.json`, this handoff, CI/test/verification evidence, packaging helpers, and checksums outside the served root. Do not publish the checkout, `.git`, `node_modules`, source tests, logs, `.env` files, deployment inventories, or operator configuration. Transfer this public-only archive through the existing authorized artifact route; do not embed credentials in commands or URLs.

From an empty operator-selected staging directory, verify the archive hash, inspect its file list, and then extract. Verify every extracted asset with the provided checksum file before activation:

```sh
sha256sum xiongan-wallet-static-763b0067.tar.gz
tar -tzf xiongan-wallet-static-763b0067.tar.gz
# PUBLIC_DIR and HANDOFF_DIR are verified local directories selected by the operator.
tar -xzf "$HANDOFF_DIR/xiongan-wallet-static-763b0067.tar.gz" -C "$PUBLIC_DIR"
(cd "$PUBLIC_DIR" && sha256sum -c "$HANDOFF_DIR/SHA256SUMS")
```

## Rebuild from the fixed source if preferred

Use an isolated clean build checkout, not an existing production checkout in place. Existing authenticated repository access must already be available; no new credentials are needed or supplied. Fetch the approved branch using that access, check out the full fixed commit, and verify both identities:

```sh
git rev-parse HEAD
git rev-parse HEAD^{tree}
git status --porcelain
node --version
npm ci --ignore-scripts
npm run typecheck
npm run wallet:browser:build
```

Use the verified checksum-repair main merge commit `763b00670752db7ed97525fca356729bbe8221d5` and tree `14abc51f3d882b4c882b162753fc279efcf01707`; the working tree must be clean. The tested repair head `744befce0643db1924c1cfb6531709223ee52e53` is source-equivalent because its tree is identical. The earlier `a45971f3` / `93934f9` tree is superseded and does not contain this checksum repair. Node must satisfy the locked project's requirement, at least 22.18.0. Do not run a dependency upgrade or rebuild from an unpinned branch. Copy only the seven named `web` assets and fresh `dist/browser/**/*.js` into the isolated public release directory. Preserve their relative layout. There are no source maps in this build. Compare hashes with the supplied manifest, or record and investigate a reproducible-build difference before activating.

The local package was built from a byte-identical verified Git tree; its local recovery-checkout commit object differs from the remote commit because of checkout reconstruction. The operator's normal repository checkout must use the remote commit above. The package's trust binding is the verified tree plus file hashes, not the local reconstruction commit.

## Serving and reverse-proxy details

The entry is `web/index.html`. Its modules import `../dist/browser/browser.js`, so both sibling trees must be served together. If the verified existing route has prefix `P`, the paths must resolve as `P/web/index.html`, `P/web/app.mjs`, and `P/dist/browser/browser.js`. A request to `P/` may redirect to `P/web/index.html`; preserve the prefix. Do not flatten the directories or use an ArtFi SPA fallback for missing wallet modules. Missing files should return 404, not another application's HTML.

Use the existing web server's static-location mechanism with a wallet-specific document root and configuration fragment. Retain correct JavaScript MIME types for `.js` and `.mjs`, CSS and HTML types, GET/HEAD-only serving, no directory listing, and no script execution or upload endpoint. No external analytics, CDN script injection, cross-origin asset hosting, wallet keys, server-side signer, or page-level RPC endpoint is required.

Reproduce the candidate's delivery headers on this route:

```text
Content-Security-Policy: default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self'; font-src 'self'; frame-ancestors 'none'; object-src 'none'; base-uri 'none'; form-action 'none'
X-Content-Type-Options: nosniff
Referrer-Policy: no-referrer
Cross-Origin-Resource-Policy: same-origin
Cache-Control: no-store
```

The HTML has a CSP meta element, but `frame-ancestors` requires the response header. Do not loosen CSP to mask a routing or MIME failure. Use the existing valid HTTPS configuration; do not bypass certificate warnings. Browser journal writes require a secure context and strict IndexedDB transaction durability. Avoid stale cached HTML or mixed-version JavaScript, since these filenames are not content-hashed. A whole-release activation is preferable to incremental file replacement. Do not add a service worker.

The repository also contains a development-only loopback server:

```sh
# Run only from the fixed build checkout. Choose a verified unused local port.
WALLET_BROWSER_PORT="$VERIFIED_LOOPBACK_PORT" npm run wallet:browser:serve
```

It binds `127.0.0.1` only. Its default port is 8415, which is not a claim that this port is available on SIN. It permits only `Host: 127.0.0.1:PORT` or `Host: localhost:PORT`, and rejects query strings. It has no RPC forwarding, signer, secret loader, upload, or write endpoint. It is suitable for an operator's local rehearsal; direct static serving is the recommended deployed shape.

If the existing operator temporarily uses it behind the already approved proxy for a rehearsal, the upstream Host must match its actual loopback address and port, and prefix rewriting must preserve both public trees. Blindly forwarding the public Host yields 403. The upstream `/` redirect points to `/web/index.html` and does not know a proxy prefix, so prefix-root redirects must be handled correctly by the proxy. Keep the listener on loopback. Do not open a public application port, change firewall policy, or present a server-local URL as a user-accessible entry.

## Preserve the original outcome journal

Browser storage belongs to the origin and browser profile, not to the SIN filesystem. Scheme, host, or port changes create a different origin. Path changes alone do not. A clean journal at a new origin does not prove that an old transaction was cancelled or never sent.

Before repeating any previously attempted intent, return to its original browser profile and original origin. Connect the same chain/account and, for 8415 controls, the same pinned controller. Do not clear site data, delete storage, reset a journal, copy signing material, or silently migrate records to make an unresolved outcome disappear.

Current journal identifiers for read-only diagnosis:

- External assets: IndexedDB `xiongan-public-assets-v1`, object store `operations`, key `xiongan-asset-v1:CHAIN_ID:LOWERCASE_ACTOR`.
- Existing 8415 controls: IndexedDB `8415-public-operation-v2`, object store `operations`, key `8415-operation-v1:CHAIN_ID:LOWERCASE_CONTROLLER:LOWERCASE_ACTOR`.
- An older localStorage record using the same key is deliberately refused for automatic migration. It needs explicit reconciliation, not deletion.

For an unknown outcome, the owner checks the genuine wallet's activity. Recover only a canonical mined transaction matching the saved intent, including an exact same-intent speed-up. A known submitted transaction can also be replaced by a matching mined hash. A different transaction consuming the same actor/nonce can be acknowledged only with verified canonical receipt proof, and the original outcome is `superseded-not-successful`. Missing hashes, wallet rejection, timeouts, unchanged nonce, or a fresh browser profile do not authorize retry. Preserve a journal across reorgs. Two confirmations are an operational display threshold, not Ethereum economic finality, Base L1 finality, ERC-8415 temporal finality, or legal title.

The original CTYun journal's exact origin/profile is not included in the available deployment evidence. The existing operator must locate it from the original task or owner session. There is no approved automatic journal migration procedure in this candidate.

## Verify before opening the candidate to the owner

1. Record the actual final URL and served release hash. Verify entry HTML, CSS, both `.mjs` entries, `ui-lock.mjs`, and all compiled imports return the expected bytes and MIME types over valid HTTPS. Check the response headers and absence of a conflicting service worker or proxy-injected scripts.
2. Verify missing assets, source files, `.git`, environment files, traversal attempts, and write methods are not served. Do not test against unrelated services.
3. Open the actual SIN URL in a browser. Confirm the English Xiongan Wallet title, development/audit notice, responsive layout, and clean console. The same-page controls must not trigger a wallet prompt just by loading or reviewing a request.
4. Recheck ArtFi and artcch's existing health and routes. Their release pointers, processes, secrets, and configuration remain unchanged.
5. The owner chooses a genuine wallet that injects the intended EIP-1193 provider as `window.ethereum`. The current build has no WalletConnect or separate mobile deep-link connection path. A generic mobile browser without that provider reports `ASSET_WALLET_PROVIDER_REQUIRED`; responsive layout alone is not mobile wallet acceptance. With multiple installed providers, the owner must verify the selected account/network in the actual wallet.
6. Rehearse on Sepolia and Base Sepolia using the owner's existing test EOAs and standard ERC-721/ERC-1155 test assets. The owner personally confirms any signing/submission in the wallet. Capture public request digest, chain, actor, asset/recipient/amount, transaction hash, canonical receipt, and journal state transitions. Avoid screenshots containing private wallet material.
7. Cover ETH transfer, ERC-721 transfer, ERC-1155 transfer, account/chain changes including A-to-B-to-A, page reload, disconnect, explicit cancellation, speed-up, matching-hash recovery, different same-nonce replacement, repeated-click prevention, and the original unresolved-outcome lifecycle. Do not label a simulated reorg as a genuine chain event.
8. Complete genuine physical mobile and intended hardware-wallet journeys. Report unsupported provider/storage behavior as a compatibility finding, rather than weakening durability or identity checks.

The external-account panel works without an 8415 deployment manifest. It supports Ethereum (1), Base (8453), Sepolia (11155111), and Base Sepolia (84532). ETH sends currently accept EOA recipients only; standard ERC-721 and ERC-1155 safe transfers require explicit NFT contract/token IDs. There is no ERC-20, swap, bridge, NFT marketplace/indexing, smart-account custody, approval flow, or standing agent permission.

The existing 8415 panel still requires its original exact public deployment manifest and remains testnet-only on Sepolia/Hoodi. Do not deploy new control contracts or point these controls at mainnet as part of UI hosting. Never use an 8415 controlled-account contract as the general ETH receive address.

Mainnet/Base real-asset use remains a separate acceptance decision after the unresolved production checks. An independent external review must name the exact candidate and scope. The assistant may prepare and check public requests and follow receipts; the owner personally performs the final real-asset signing/submission in the wallet's secure interface. General future authorization is not an unlimited session grant or a concrete transfer instruction.

## Activation and rollback

Use the existing release mechanism with a wallet-specific immutable release directory. Validate the relevant server configuration using its existing supported check before a targeted reload or activation. Record before/after wallet route references and the exact release hash. Do not restart unrelated services or replace a shared document root.

For rollback, restore only the wallet route or release reference using the existing operator workflow. Keep browser journal data intact. Do not roll an active journal back to an incompatible code version; preserve the original origin and available recovery path, and let the owner reconcile unresolved intent before another send. If recovery compatibility is uncertain, stop new wallet actions and preserve the evidence rather than erasing browser data. Recheck the other SIN applications after rollback.

## Return to the release owner

Provide the verified deployment task/executor, final HTTPS URL, exact served commit/tree and artifact hash, wallet-only configuration summary, static delivery checks, and unchanged ArtFi/artcch health. Separately list real-wallet journeys actually completed, public receipts, recovery results, physical-device coverage, and outstanding independent audit findings. If the existing executor or original origin cannot be located, return that exact blocker. Do not report a live URL, successful SIN deployment, or production acceptance until observed.
