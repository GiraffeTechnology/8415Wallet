Checksum repair recovery candidate

Base: GiraffeTechnology/8415Wallet main 93934f9bc5524b3989e2f10f0dc35d86b5b2835b
Tree: 8fcb1624c98afb3e9e69a8d19d4a9fbdf65f7d71

source/ contains the candidate source, config, tests and docs. Two tracked Python cache bytecode files are omitted; source Python files are present. source is reconstructed from verified GitHub blobs rather than a Git clone. Local synthetic Git history is intentionally omitted.

To reproduce on a full checkout: git checkout 93934f9bc5524b3989e2f10f0dc35d86b5b2835b; git apply checksum.patch; npm ci; npm run typecheck; npm test; npm run wallet:browser:build; npm run test:evm. Run npm run wallet:xiongan:smoke on a host that permits Chromium local sockets.

manifest.json records source and patch hashes, changes, checks and limits. logs/ contains local command evidence. browser-dist/ is the local TypeScript browser emit for inspection, not a deployment.

No keys, signing, public chain transaction, mainnet/testnet deployment, audit approval or real-asset acceptance is included. The existing delivery package is unchanged.

Published draft PR44: https://github.com/GiraffeTechnology/8415Wallet/pull/44
Candidate commit: 744befce0643db1924c1cfb6531709223ee52e53
Candidate tree: 14abc51f3d882b4c882b162753fc279efcf01707
Remote tree checked: exactly 9 expected paths/blobs, no deletion. Exact-head Node22/24 CI must pass before release owner merges.

Final CI: run 37098073411 completed SUCCESS on the exact candidate head, all steps of both Node22/24 jobs passed, including real Chromium synthetic desktop/mobile recovery. See exact-head-ci.json. This is not genuine wallet or real-asset acceptance.
