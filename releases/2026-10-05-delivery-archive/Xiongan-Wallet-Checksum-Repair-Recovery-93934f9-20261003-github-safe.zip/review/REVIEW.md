# Bounded independent checksum repair review

Date: 2026-10-03 UTC. Reviewer: independent AI-assisted code review, not an external professional security audit.

## Verdict

The previously reproduced mixed-case ERC-55 address-checksum finding is closed in the reviewed candidate source. No additional finding was identified within this nine-file repair scope. No repository implementation files were changed by this reviewer. No wallet was connected, no key or credential was read, and no real transaction was signed or submitted.

## Exact reviewed identity

- Intended remote base: GiraffeTechnology/8415Wallet main `93934f9bc5524b3989e2f10f0dc35d86b5b2835b`, tree `8fcb1624c98afb3e9e69a8d19d4a9fbdf65f7d71`.
- Candidate directory: `/workspace/scratch/b6045b8d6597/wallet-checksum-candidate`.
- Nine-file patch: `/workspace/scratch/b6045b8d6597/wallet-checksum-candidate.patch`.
- Independently verified patch SHA-256, including a second hash of `git diff --cached --binary`: `40febff9c44ed07adbebffa284d97db5b18b73ac6d2537287de234bbbc2c83c9`.
- The directory's local HEAD `cd7d35a164791512a7ae8923500366580b31f784` is a synthetic restored-base commit, not the remote main commit. It must not be used as a claim of remote provenance or pushed as reconstructed history. Publication should apply this exact patch to the verified remote base.
- Independently matched original source blobs for externalAssets.ts `99b953881bc04f256ad5287b65897b4123cf9aa3`, agentRequest.ts `33e9a7d1251b439d4f28440e2d821a89ff17f6a1`, and original asset tests `9d47943603852fe98e42ad01a8c4bde1a68dd712` to the earlier main review.

## Closure evidence

- `src/xiongan/address.ts:6-12` checks shape and nonzero value, accepts deliberately unchecksummed lowercase/uppercase bodies, and validates mixed case using existing `keccak256Utf8` before normalization.
- `src/xiongan/externalAssets.ts:23,62,104,114` applies the policy to request actor, ETH/NFT recipient and NFT contract inputs.
- `src/xiongan/externalAssets.ts:148` retains submit-time reconstruction from original request text, so an invalid-checksum request introduced after an earlier valid review is rejected before send.
- `src/xiongan/agentRequest.ts:33-34,55-56,70` validates JSON address inputs, including controlled-account withdrawal destination, while provider context remains byte-oriented.
- Original RPC/journal `addr` remains unchanged at externalAssets.ts:22. Account and receipt normalization at :76 and :181-182 remains case-insensitive byte matching. A deliberate non-checksummed mixed-case RPC response still reconciles successfully in the regression test.
- Actual `external-assets.mjs` form/file handlers were exercised through a deterministic DOM/provider harness: bad recipient/contract checksum clears a previous review, and checking acknowledgement plus clicking send does not produce a wallet request.
- Official ERC-55 vectors, lower/upper compatibility, one-letter case mutations, and 64 deterministic address families with ethers validation as an independent comparison all pass.
- The browser emit contains `dist/browser/xiongan/address.js`; both emitted externalAssets and agentRequest modules import it. No package.json, package-lock.json or CI workflow changes, runtime dependency additions, signing routes, permissions or new release gates are in this patch.

## Independently executed checks

1. Candidate focused suite: 69 tests passed, zero failures/skips/cancellations.

   Command, from the candidate directory:
   `node --test tests/xiongan-address.test.ts tests/xiongan-address-ui.test.ts tests/xiongan-assets.test.ts tests/xiongan-agent.test.ts tests/browser-connection.test.ts`

   Log: `/workspace/scratch/b6045b8d6597/wallet-checksum-focused-review.log`

2. Reused reviewer checks: 38 tests passed, zero failures/skips/cancellations.

   The previous 26 adversarial checks and 12 external-UI handler checks were copied into a separate review directory and redirected to candidate source. Only the prior defect-positive expectation was changed to require ASSET_ADDRESS_REFUSED and zero sends. Candidate repository tests/source were not edited by this reviewer.

   Command, from `/workspace/scratch/b6045b8d6597`:
   `node --test wallet-checksum-independent-review/*.test.ts`

   Tests: `/workspace/scratch/b6045b8d6597/wallet-checksum-independent-review/reviewer-adversarial.test.ts` and `/workspace/scratch/b6045b8d6597/wallet-checksum-independent-review/reviewer-external-ui.test.ts`

   Log: `/workspace/scratch/b6045b8d6597/wallet-checksum-independent-review.log`

## Boundaries

These 69+38 checks are Node tests with deterministic provider/DOM and memory-store fixtures. They establish source-level refusal and preserved regression behavior; they do not establish actual Chromium IndexedDB durability, genuine wallet UX, real receipts, physical devices or deployed SIN behavior. The implementation worker's reported 812 Node / 59 EVM, typecheck/browser/reference-client and packaging results were not independently rerun in this bounded review. The reported local Chromium socket EPERM remains a browser-execution blocker, not a local-browser pass. Remote commit identity and exact-head CI are for the parent to verify after publication. Valid checksum does not verify recipient ownership, trustworthiness or transaction safety, and deliberately unchecksummed lowercase/uppercase inputs retain their documented compatibility boundary.
