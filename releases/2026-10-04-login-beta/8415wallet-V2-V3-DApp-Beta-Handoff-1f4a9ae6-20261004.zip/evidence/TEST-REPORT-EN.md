# Wallet login Beta verification report

Date: 2026-10-04 UTC. Merged commit `1f4a9ae6dd5b8b062ab4f903920cf4b39d158e36`; content tree `366a1b4e744d6414dce6a1feab390a3fe1a99095`.

## Exact-source result

Candidate `003eb25500e45f06da65acac8ac84b093d6b04c3` and merged main have the same content tree. Candidate run
37208959527 and merged-main run 37209416014 each passed both complete Node 22/24
jobs. See candidate-ci.json and post-merge-ci.json for exact heads and all steps.

The delivered V2, Xiongan V2 and V3 archives are fresh clean builds from the merged
commit under Node 22.23.3, with the lockfile-pinned TypeScript/ethers toolchain.
Their manifests, source archive, config/PRD/runtime identities and exact inventory
were verified. The Xiongan artifact was rebuilt twice with an identical hash.

## Local matrix

Node 22.23.3 and Node 24.19.0 each passed:

- TypeScript typecheck and 1,069 Node cases
- 89 actual local-EVM cases
- Browser build and reference CLI
- 16 DApp packaging contract cases
- V2 SDK external install: 8 checks; V3 SDK external install: 9 checks
- V2/V3 complete artifact/source/config/module verification
- Byte-identical repeated DApp/source builds

The local offline lockfile install passed with lifecycle scripts disabled;
normal npm ci also passed in both hosted CI jobs. Counts overlap with focused
review tests and must not be added together.

## Authentication and lifecycle coverage

Forty-five core and actual-authentication-handler cases cover real synthetic
EIP-191 recovery, EIP-1271 acceptance/refusal/revocation, exact message-field
binding, wrong/replayed signatures, nonce collision, expiry/clock reversal,
pre-challenge cancellation, account-permission events, account/chain/origin
changes, pending signature cancellation, held-read silent identity/revocation
changes, memory-only reload denial and provider address casing compatibility.

Additional actual native/external/clearing handlers test review invalidation,
clearing form-identifier purge and signed V3 consent continuity/purge. Scope
review found and repaired release-profile cancellation, stale form identifiers,
locked/pre-challenge chain/disconnect handling and post-response identity checks.
The scoped review independently passed 124 focused cases, then 45 final delta
cases and typecheck. This is implementation review, not a security audit.

## Rendered browser evidence

Both exact-source CI jobs passed real Chromium at desktop and mobile viewports:

- Public entry with zero provider calls and denial of hidden-handler bypass
- Connection-versus-login separation, reject/invalid/replay, cancel and repeat click
- Both V2 and V3 login/privacy journeys, logout, reload/storage denial,
  account/chain/disconnect, late ETH/ERC-20 reads and expiry
- Existing ETH/ERC-20 transaction review, synthetic send, IndexedDB recovery,
  unknown outcomes and exact receipt checks
- Native settlement recovery against an actual local EVM

The synthetic fixtures use public test keys, not user credentials or genuine
wallet signatures. Mobile viewports are not physical handsets. The local cloud
execution environment denied Chromium's socket operation, so no local rendered
pass is claimed. Hosted CI supplied the rendered evidence. Its eight archive
hashes were checked and preserved under evidence/browser/.

## Acceptance boundary

The public entry stays open and the DApp protects asset display behind a verified
login. Public blockchain data stays public. Browser storage is not encrypted,
private APIs need independent server authorization, and durable unresolved
transaction journals must not be deleted to bypass recovery.

No live deployment, user wallet, user private key/signature, mainnet/public-chain
transaction or comprehensive independent security audit was used. Genuine
provider/device compatibility, deployed endpoint/headers/rollback and W-20 remain
manual acceptance work under separate authorization. Existing standards coverage
and limitations are listed in docs/STANDARDS-COMPATIBILITY.md.
