# 8415wallet V2/V3 DApp Beta manual deployment handoff

This version adds verified wallet login before asset/history display. The public
entry remains open. It supersedes the previous Beta handoff while preserving
that earlier version in Library history. This kit does not deploy a server,
use a genuine wallet or authorize any transaction or server change.

## Exact source and verification

- Merged main: `1f4a9ae6dd5b8b062ab4f903920cf4b39d158e36`
- Reviewed content tree: `366a1b4e744d6414dce6a1feab390a3fe1a99095`
- Pre-merge candidate: `003eb25500e45f06da65acac8ac84b093d6b04c3`
- PR: https://github.com/GiraffeTechnology/8415Wallet/pull/50
- Candidate CI: https://github.com/GiraffeTechnology/8415Wallet/actions/runs/37208959527
- Merged-main CI: https://github.com/GiraffeTechnology/8415Wallet/actions/runs/37209416014

Both CI runs completed successfully on Node 22 and Node 24. Candidate and merged
content trees are identical. These are new clean builds whose manifests name
the merged commit; no earlier archive has been relabeled.

## Choose the DApp

8415wallet is the general-purpose wallet product, compatible with existing wallet
and asset standards with additive native ERC-8415 support. 8415wallet.com is the
platform domain. Xiongan is a V2 tenant.

- `dapps/v2-platform/`: V2 Beta 2.2.0-beta, retained PRD v2.2 sections 1–8
- `dapps/v2-xiongan/`: the same V2 product profile configured for Xiongan
- `dapps/v3-platform/`: V3 Beta 3.0.0-beta, retained foundation plus PRD section 9
- `source/`: exact content-tree backup without .git
- `optional-sdk/`: separately verified SDK/CLI packages, not substitute websites

Each DApp includes RELEASE.json, SHA256SUMS, exact source/PRD/profile identities,
configuration and runtime hashes. Keep its web/ and dist/browser/ layout intact.
The browser entry is web/index.html. Verify this kit's SHA256SUMS and each archive's
manifest and extracted checksums before serving it.

## Login behavior

Read `docs/WALLET-LOGIN.md`. A provider connection alone cannot display assets.
The user must approve an origin/account/chain-bound login message. EOAs are
cryptographically recovered; supported contract accounts require ERC-1271.
The nonce is single-use, the challenge expires after two minutes, and login lasts
at most 15 minutes in this tab. No login credential is persisted. Reload, logout,
expiry, account/chain changes, disconnect and history restoration lock the display.

Logout clears displayed balances, holdings, histories, receive addresses,
submission identifiers and unsigned reviews. In-flight stale results are rejected.
Recovery journals remain saved and require fresh login/connection to inspect.
An already-signed V3 recipient consent has its documented private-memory handoff
exception across an account switch, while logout/expiry/chain change/disconnect
clear it. Login never replaces the separate wallet approval for a transaction.

Public blockchain records remain public. This is DApp display privacy, not an
entitlement system or private-API authorization. Any future private API requires
independent server-side authentication and authorization. External asset custody
remains EOA-only; deployed ERC-1271 login support does not claim every smart wallet
or counterfactual account works. No keys or seed phrases are imported.

## Required deployment inputs

1. The authorized environment and exact public entry URL, including scheme,
   hostname, explicit allocated port and /web/index.html.
2. Verified public testnet contract manifests, exact chain IDs, addresses and
   runtime hashes. Omit optional controllers/payments for standalone use.
3. Authorized test accounts/assets and the intended genuine wallet/browser.

Deployment URLs are intentionally null. Do not invent a port or endpoint. Rebuild
with the confirmed configuration using `docs/BETA-DAPP-DELIVERY.md`; record the
new configuration and artifact hashes. TCP 443 is reserved for SSH on managed
origin hosts. Do not change listeners, SSH, DNS, TLS termination, firewalls or
credentials from this kit. A separate external TLS front door needs its own
confirmed allocation. Preserve the existing origin and recovery journals during
release changes and rollback. Rollback cannot reverse a chain transaction.

## Manual tests on the authorized deployment

- Open the public link while logged out. Confirm no asset/history or cached
  previous-account content is shown, even after browser Back/Forward or reload.
- Reject/cancel login once; verify no assets load. Check the exact site origin,
  selected account/chain and expiry in the wallet before approving fresh login.
- Test logout, expiry, account changes, chain changes, delayed provider replies
  and reload. No previous review or submission identifier may reappear.
- Exercise enabled ETH/ERC-20/ERC-721/ERC-1155 transfer/recovery paths with exact
  owner review. ERC-20 amounts are integer raw units; metadata does not establish
  identity or assumed decimals. No new allowance or unattended send flow exists.
- Exercise native projection/temporal/history views, begin/finalize/cancel
  settlement, legacy single-trade clearing and the selected V3 linked scenarios.
- Record genuine provider prompts, public-testnet receipts, physical device
  journeys and W-20 same-token multi-wallet funded/unfunded observations.

The evidence folder contains precise CI steps, local test/build results and eight
hash-verified browser-evidence archives, including screenshots and result.json.
Those archived copies remain usable after GitHub's short artifact retention ends.
Synthetic browser/local-EVM tests are not genuine-wallet/device acceptance or a
comprehensive independent security audit. No deployment has been performed.
